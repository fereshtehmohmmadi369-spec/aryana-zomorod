# Ariana Zomorod — GitHub Pages

این پوشه آماده‌ی آپلود در GitHub Pages است.

ساختار:
- index.html
- logo.png
- portfolio/

عکس‌های مدل‌ها را با نام‌های زیر داخل portfolio قرار دهید:
work1.jpg تا work4.jpg
more1.jpg تا more11.jpg

بعد کل محتویات این پوشه را داخل Repository گیت‌هاب آپلود کنید.
